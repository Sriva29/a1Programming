# a1Programming

This is a programming assignment to demonstrate my understanding of data structures, for loops, and functions in JavaScript.
